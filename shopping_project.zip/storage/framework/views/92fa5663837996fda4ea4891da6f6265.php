<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\xampp_new\htdocs\shopping_project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>