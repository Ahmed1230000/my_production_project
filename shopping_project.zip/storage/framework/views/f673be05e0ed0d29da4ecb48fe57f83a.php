<?php echo e($slot); ?>

<?php /**PATH C:\xampp_new\htdocs\shopping_project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>